# US Pre-market Brief (v6.3) – automatic daily site

This repository runs the US pre-market brief v6.3 (the same two scripts used in Google Colab) on GitHub Actions every US trading day and publishes a dashboard website with GitHub Pages.

- **Daily pre-market brief** (`.github/workflows/brief.yml`): about 07:17 New York time, Monday to Friday. Runs cell 1 over the S&P 500, Nasdaq 100 and S&P 400 and rebuilds the website.
- **Pre-open update** (`.github/workflows/preopen.yml`): about 08:47 New York time. Runs cell 2 against that morning's plan and adds it to the website.
- Website: `https://<your-user-name>.github.io/<repository-name>/`. `latest/tc.html` always opens the newest full brief. The pages are in Traditional Chinese, as v6.3 writes them.

## Setup in short

1. Upload everything in this folder to a new **public** repository (GitHub Pages is free for public repositories).
2. Settings → Secrets and variables → Actions:
   - Secrets (optional): `ANTHROPIC_API_KEY` (paid, for AI news) and `FRED_API_KEY` (free, for credit spreads and NFCI).
   - Variables (all optional): `DEMO_ACCOUNT` (default 100000), `RISK_PCT` (0.75), `MAX_HEAT_PCT` (0), `UNIVERSE` (`sp500+ndx100+sp400`), `EXTRA_TICKERS`, `DEMO_POSITIONS`, `HTF_WIDE_SCAN` (false), `USE_OPENBB` (true), `AI_NEWS` (false), `AI_MODEL`, `ARCHIVE_DAYS` (30).
3. Settings → Pages → Build and deployment → Source: **GitHub Actions**.
4. Actions → Daily pre-market brief → Run workflow. When it finishes, open the site address shown on the run page.

The website is public. Do not put your real account size or positions in `DEMO_ACCOUNT` or `DEMO_POSITIONS`.

## Files

| Path | What it is |
| --- | --- |
| `scripts/premarket_brief_v6_3.py` | Cell 1, unchanged from the Colab version |
| `scripts/preopen_update_v6_3.py` | Cell 2, unchanged from the Colab version |
| `runner/common.py` | Runs a Colab script on Actions: Colab stand-ins and form values from variables |
| `runner/run_brief.py`, `runner/run_preopen.py` | Run cell 1 / cell 2 and save the website copies |
| `runner/build_site.py` | Builds the dashboard pages from the saved summaries |
| `runner/time_window.py` | Lets one of the two daily schedules through (US daylight saving) |
| `runner/state.sh` | Saves and restores history on the `data` branch (one commit, replaced each run) |

History (daily log, tier history, plan file, score history, website archive) lives on the `data` branch. Delete that branch to start fresh.

To update the scripts later, replace the two files in `scripts/`. If the new file names differ (for example v6.4), change `SCRIPT` near the top of `runner/run_brief.py` and the file name in `runner/run_preopen.py`.

For research and demonstration only. Not investment advice; data can be late or wrong, and nothing here guarantees a profit.
